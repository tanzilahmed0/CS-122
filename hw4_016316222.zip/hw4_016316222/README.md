# CS 122 Homework 4

## Summary of Insights

### Top Users by Engagement
The most engaged users are 1082, 1037, and 1024, each with 370 total engagement points (combined average likes and shares).

### Popular Hashtags
The top 5 most popular hashtags are:
1. #outdoorfun (27 occurrences)
2. #foodie (26 occurrences)
3. #cozytime (20 occurrences)
4. #goodtimes (20 occurrences)
5. #adventure (20 occurrences)

### Sentiment Analysis
- 66% of posts are positive
- 20% are neutral
- 14% are negative

Overall, the social media posts are primarily positive.


